Function to generate 3d array consisting of a 2d connectome for each participant

Inputs are the path to the CONN ROI.mat file,the number of ROIS and the number of subjects
