def test_function(input):
    output=input+2
    return(output)




def create_connectomes(conn_ROI_path, num_rois, num_partic):
    from scipy.io import loadmat
    import numpy as np
    rawdata = loadmat(conn_ROI_path)
    ROI = rawdata['ROI']
    values = range(0, num_rois)
    init_array = np.empty((1, num_rois), dtype=object)
    connectomes = np.empty([num_rois, num_rois, num_partic])

    for val in values:
        init_array[0, val] = (ROI[0, val][1])[:, val:num_rois]

    data = np.hstack(init_array.flatten())
    nans_removed = data[:, ~np.all(np.isnan(data), axis=0)]

    for i in range(num_partic):
        a = nans_removed[i, ]
        # create top triangle of matrix
        b = np.triu(np.ones(num_rois), 1)
        b[b.astype(bool)] = a
        # Fill the 3d array
        connectomes[:, :, i] = b + b.transpose()

    return (connectomes)
