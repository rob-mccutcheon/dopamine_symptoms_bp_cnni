from scipy.io import loadmat
from scipy.stats import pearsonr, spearmanr
import pandas as pd
import numpy as np
import bct  # Edited the louvain function as  crashing commented out lines 110-111 of modularity.py and correct bugs
from collections import defaultdict
import nibabel as nib

def create_connectomes(conn_ROI_path, num_rois, num_partic):
    rawdata = loadmat(conn_ROI_path)
    ROI = rawdata['ROI']
    values = range(0, num_rois)
    init_array = np.empty((1, num_rois), dtype=object)
    connectomes = np.empty([num_rois, num_rois, num_partic])

    for val in values:
        init_array[0, val] = (ROI[0, val][1])[:, val:num_rois]

    data = np.hstack(init_array.flatten())
    nans_removed = data[:, ~np.all(np.isnan(data), axis=0)]

    for i in range(num_partic):
        a = nans_removed[i, ]
        # create top triangle of matrix
        b = np.triu(np.ones(num_rois), 1)
        b[b.astype(bool)] = a
        # Fill the 3d array
        connectomes[:, :, i] = b + b.transpose()

    return (connectomes)


def consensus_clustering_louvain(inputMatrix, numberPartitions, consensusMatrixThreshold, LouvainMethod, gamma):
    # Function to implement consensus clustering as per Lancichinetti & Forunato et al 2012
    # using the Louvain algorithm as implemented by BCT
    #
    # Inputs:
    #   inputMatrix                 symmetrical weighted undirected adjacency matrix to be partiitioned
    #   numberIterations            number of times the algorithm is run to  generate the consensus matrix on each run
    #   consensusMatrixThreshold    threshold below which consensus matrix  entries are st to zero, (0 1]
    #   LouvainMethod               string of Louvain method: 'Modularity' (if no negative weights in the inputMatrix,
    #                               or 'negative_sym' / 'negative_asym' if negative weights)
    #   gamma                       resolution parameter of Louvain
    #
    # Outputs:
    #   finalPartition              final community allocaiton of each node
    #   iterations                  how many iterations to reach consensus
    #   communityAssignment         final community assignment

    consensus = False
    iterations = 0

    while not consensus:
        D = np.zeros((inputMatrix.shape[0], inputMatrix.shape[1], numberPartitions))  # consensus matrix
        # generate consensus matrix
        for partition in range(numberPartitions):
            [community_allocation, ignore_Q] = bct.community_louvain(inputMatrix, gamma=gamma, ci=None, B=LouvainMethod, seed=None)

            for row in range(D.shape[0]):
                for col in range(D.shape[1]):
                    D[row, col, partition] = (community_allocation[row] == community_allocation[col])

        D = np.mean(D, 2)  # consensus matrix...is it equal or do we need to keep going?
        iterations = iterations + 1  # keep track

        if np.unique(D).shape[0] < 3:  # only true if all parition matrices equal (so that their mean is either 0 or 1)
            consensus = True
            finalPartition = D
            communityAssignment = defaultdict(list)
            for community in range(1, np.unique(community_allocation).shape[0]+1):
                communityAssignment[community].append(np.where(community_allocation == community))

        else:
            D = np.where(D < consensusMatrixThreshold, 0, D)
            inputMatrix = D

    return(finalPartition, iterations, communityAssignment)


def atlas2rois(atlas_file, roi_directory):
    #turns an atlas file into indivdual rois and saves them
    atlas = nib.load(atlas_file, mmap=False)
    affine = atlas.affine
    for i in range(1, int(np.max(atlas.get_data()))+1):
        roi = np.where(atlas.get_data()==i,1,0)
        roi_nii = nib.Nifti1Image(roi, affine)
        roi_nii.header.set_data_dtype('float32')
        nib.save(roi_nii, ('%(1)sroi_%(2)s.nii' % {"1":roi_directory, "2": i}))



def cor_matrix(dataframe, method):
    coeffmat = pd.DataFrame(index=corr_data.columns, columns=corr_data.columns)
    pvalmat = pd.DataFrame(index=corr_data.columns, columns=corr_data.columns)
    for i in range(corr_data.shape[1]):
        for j in range(corr_data.shape[1]):
            x = np.array(corr_data[corr_data.columns[i]])
            y = np.array(corr_data[corr_data.columns[j]])
            bad = ~np.logical_or(np.isnan(x), np.isnan(y))
            if method == 'spearman':
                corrtest = spearmanr(np.compress(bad,x), np.compress(bad,y))
            if method == 'pearson':
                corrtest = pearsonr(np.compress(bad,x), np.compress(bad,y))
            coeffmat.iloc[i,j] = corrtest[0]
            pvalmat.iloc[i,j] = corrtest[1]
    return (coeffmat, pvalmat)
