from setuptools import setup

setup(
    name='connectome_builder',
    py_modules=['connectome_builder']
)
